// MeetingPOLL - Application Logic

// API URL Prefix (handles relative paths)
const API_BASE = '/api';

// Application State
let state = {
    currentView: 'create', // 'create' | 'vote' | 'results'
    selectedDate: new Date(), // Date object for calendar
    proposedSlots: [], // Array of { id, start_time (ISO), end_time (ISO) }
    currentPoll: null, // Fetched poll object
    voterChoices: {}, // slot_id -> choice for voting view
    detectedTimezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    selectedTemplateTab: 'email' // 'email' | 'slack'
};

// Common/All Timezones setup
let availableTimezones = [
    "UTC", "America/New_York", "America/Chicago", "America/Denver", 
    "America/Los_Angeles", "Europe/London", "Europe/Paris", "Europe/Moscow", 
    "Asia/Tokyo", "Asia/Singapore", "Asia/Kolkata", "Asia/Dubai", "Australia/Sydney"
];

try {
    // Attempt to load full IANA timezone list supported by browser
    availableTimezones = Intl.supportedValuesOf('timeZone');
} catch (e) {
    console.warn("Intl.supportedValuesOf not supported, using fallback timezone list.");
}
if (!availableTimezones.includes("UTC")) availableTimezones.push("UTC");
if (!availableTimezones.includes(state.detectedTimezone)) availableTimezones.push(state.detectedTimezone);
availableTimezones.sort();

// Helper: Show/Hide spinner
function showLoading(show) {
    const spinner = document.getElementById('loading-spinner');
    if (spinner) {
        if (show) spinner.classList.remove('hidden');
        else spinner.classList.add('hidden');
    }
}

// Helper: Toast Notifications
function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;

    container.appendChild(toast);

    // Auto-remove after 4 seconds
    setTimeout(() => {
        toast.style.animation = 'toast-slide-in 0.3s reverse';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// Helper: Format slot ISO times into viewer local time
function formatSlotTimeRange(startIso, endIso, timezone) {
    try {
        const start = new Date(startIso);
        const end = new Date(endIso);
        
        let tz = timezone;
        try {
            // Verify timezone validity
            new Intl.DateTimeFormat('en-US', { timeZone: tz });
        } catch (e) {
            tz = 'UTC';
        }
        
        const dateOpts = {
            timeZone: tz,
            weekday: 'long',
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        };
        
        const timeOpts = {
            timeZone: tz,
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        };
        
        const formattedDate = new Intl.DateTimeFormat('en-US', dateOpts).format(start);
        const formattedStartTime = new Intl.DateTimeFormat('en-US', timeOpts).format(start);
        const formattedEndTime = new Intl.DateTimeFormat('en-US', timeOpts).format(end);
        
        // Grab weekday/month details for badges
        const day = new Intl.DateTimeFormat('en-US', { timeZone: tz, day: 'numeric' }).format(start);
        const month = new Intl.DateTimeFormat('en-US', { timeZone: tz, month: 'short' }).format(start);
        const weekday = new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'short' }).format(start);
        
        return {
            dateString: formattedDate,
            timeRange: `${formattedStartTime} - ${formattedEndTime}`,
            day: day,
            month: month,
            weekday: weekday
        };
    } catch (err) {
        // Fallback on formatting error
        return {
            dateString: startIso.split('T')[0],
            timeRange: `${startIso.split('T')[1].substring(0,5)} - ${endIso.split('T')[1].substring(0,5)}`,
            day: '?',
            month: '?',
            weekday: '?'
        };
    }
}

// Helper: Create UTC ISO string from a date string and target timezone
function convertToUTC(date, tz) {
    let targetTz = tz;
    try {
        new Intl.DateTimeFormat('en-US', { timeZone: targetTz });
    } catch (e) {
        targetTz = 'UTC';
    }

    const formatter = new Intl.DateTimeFormat('en-US', {
        timeZone: targetTz,
        year: 'numeric', month: 'numeric', day: 'numeric',
        hour: 'numeric', minute: 'numeric', second: 'numeric',
        hourCycle: 'h23'
    });
    
    const parts = formatter.formatToParts(date);
    const partValues = {};
    parts.forEach(p => partValues[p.type] = p.value);
    
    // Construct local clock representation as a UTC timestamp (avoids system local timezone)
    const targetLocalUTC = Date.UTC(
        parseInt(partValues.year, 10),
        parseInt(partValues.month, 10) - 1,
        parseInt(partValues.day, 10),
        parseInt(partValues.hour, 10),
        parseInt(partValues.minute, 10),
        parseInt(partValues.second, 10)
    );
    
    // Construct absolute UTC representation as a UTC timestamp
    const baseUTC = Date.UTC(
        date.getUTCFullYear(),
        date.getUTCMonth(),
        date.getUTCDate(),
        date.getUTCHours(),
        date.getUTCMinutes(),
        date.getUTCSeconds()
    );
    
    // Offset is target clock time - UTC clock time
    const diff = targetLocalUTC - baseUTC;
    
    // Return absolute time minus offset
    return new Date(date.getTime() - diff).toISOString();
}

// Helper: Populate timezone select elements
function populateTimezoneDropdowns() {
    const tzSelects = [
        { id: 'poll-timezone', defaultVal: state.detectedTimezone },
        { id: 'vote-voter-timezone', defaultVal: state.detectedTimezone },
        { id: 'results-viewer-timezone', defaultVal: state.detectedTimezone }
    ];

    tzSelects.forEach(sel => {
        const el = document.getElementById(sel.id);
        if (!el) return;
        el.innerHTML = '';
        availableTimezones.forEach(tz => {
            const opt = document.createElement('option');
            opt.value = tz;
            opt.textContent = tz;
            if (tz === sel.defaultVal) opt.selected = true;
            el.appendChild(opt);
        });
    });
}

// -------------------------------------------------------------
// CALENDAR WIDGET LOGIC (Create View)
// -------------------------------------------------------------
let calMonth = new Date().getMonth();
let calYear = new Date().getFullYear();

function renderCalendar() {
    const grid = document.getElementById('calendar-days-grid');
    const monthYearLabel = document.getElementById('cal-month-year');
    if (!grid || !monthYearLabel) return;

    grid.innerHTML = '';

    const firstDayIndex = new Date(calYear, calMonth, 1).getDay();
    const lastDay = new Date(calYear, calMonth + 1, 0).getDate();
    const prevLastDay = new Date(calYear, calMonth, 0).getDate();

    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    monthYearLabel.textContent = `${monthNames[calMonth]} ${calYear}`;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Render Previous Month's Days
    for (let x = firstDayIndex; x > 0; x--) {
        const dayDiv = document.createElement('div');
        dayDiv.className = 'calendar-day other-month';
        dayDiv.textContent = prevLastDay - x + 1;
        grid.appendChild(dayDiv);
    }

    // Render Current Month's Days
    for (let i = 1; i <= lastDay; i++) {
        const dayDiv = document.createElement('div');
        dayDiv.className = 'calendar-day';
        dayDiv.textContent = i;

        const currentDayDate = new Date(calYear, calMonth, i);
        
        // Highlight Selected Date
        if (state.selectedDate && 
            state.selectedDate.getDate() === i && 
            state.selectedDate.getMonth() === calMonth && 
            state.selectedDate.getFullYear() === calYear) {
            dayDiv.classList.add('selected');
        }

        // Highlight if this day contains any proposed slots
        const hasSlotsOnDay = state.proposedSlots.some(slot => {
            const slotDate = new Date(slot.start_time);
            return slotDate.getDate() === i && 
                   slotDate.getMonth() === calMonth && 
                   slotDate.getFullYear() === calYear;
        });
        if (hasSlotsOnDay) {
            dayDiv.classList.add('has-slots');
        }

        // Disable Past Days
        if (currentDayDate < today) {
            dayDiv.classList.add('past-day');
        } else {
            // Click listener for valid days
            dayDiv.addEventListener('click', () => {
                state.selectedDate = new Date(calYear, calMonth, i);
                renderCalendar();
                updateSelectedDateLabel();
            });
        }

        grid.appendChild(dayDiv);
    }
}

function updateSelectedDateLabel() {
    const label = document.getElementById('selected-date-label');
    if (!label) return;
    
    const opts = { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' };
    label.textContent = state.selectedDate.toLocaleDateString('en-US', opts);
}

// -------------------------------------------------------------
// PROPOSED SLOTS MANAGEMENT (Create View)
// -------------------------------------------------------------
function addProposedSlot() {
    const timeInput = document.getElementById('slot-start-time');
    const durationSelect = document.getElementById('poll-duration');
    const tzSelect = document.getElementById('poll-timezone');
    
    if (!timeInput || !durationSelect || !tzSelect) return;
    
    const timeVal = timeInput.value; // "HH:MM"
    if (!timeVal) {
        showToast("Please select a time.", "error");
        return;
    }

    const [hours, minutes] = timeVal.split(':').map(Number);
    const duration = parseInt(durationSelect.value, 10);
    const chosenTz = tzSelect.value;

    // Build the slot date-time representation in UTC to avoid local system DST shifts
    const year = state.selectedDate.getFullYear();
    const month = state.selectedDate.getMonth();
    const day = state.selectedDate.getDate();
    const slotStart = new Date(Date.UTC(year, month, day, hours, minutes, 0, 0));

    // Convert slotStart time to UTC based on chosen timezone offset
    const utcDateStr = convertToUTC(slotStart, chosenTz);
    const utcStart = new Date(utcDateStr);
    const utcEnd = new Date(utcStart.getTime() + duration * 60000);

    const slotId = 'slot-' + Math.random().toString(36).substring(2, 11);
    
    // Check if slot already exists
    const duplicate = state.proposedSlots.some(s => s.start_time === utcStart.toISOString());
    if (duplicate) {
        showToast("This slot has already been proposed.", "error");
        return;
    }

    state.proposedSlots.push({
        id: slotId,
        start_time: utcStart.toISOString(),
        end_time: utcEnd.toISOString()
    });

    // Sort proposed slots chronologically
    state.proposedSlots.sort((a, b) => new Date(a.start_time) - new Date(b.start_time));

    renderProposedSlots();
    renderCalendar();
    showToast("Time slot added.");
}

function renderProposedSlots() {
    const list = document.getElementById('proposed-slots-list');
    const countLabel = document.getElementById('slots-count');
    if (!list || !countLabel) return;

    list.innerHTML = '';
    countLabel.textContent = state.proposedSlots.length;

    if (state.proposedSlots.length === 0) {
        list.innerHTML = `<li class="empty-list-msg">No slots added yet. Select dates on the calendar and add times.</li>`;
        return;
    }

    const tzSelect = document.getElementById('poll-timezone');
    const tz = tzSelect ? tzSelect.value : state.detectedTimezone;

    state.proposedSlots.forEach(slot => {
        const formatted = formatSlotTimeRange(slot.start_time, slot.end_time, tz);
        
        const li = document.createElement('li');
        li.innerHTML = `
            <div class="slot-info">
                <span class="slot-date">${formatted.dateString}</span>
                <span class="slot-time">${formatted.timeRange}</span>
            </div>
            <button class="delete-slot-btn" title="Remove slot" data-id="${slot.id}">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                </svg>
            </button>
        `;

        li.querySelector('.delete-slot-btn').addEventListener('click', (e) => {
            const id = e.currentTarget.getAttribute('data-id');
            state.proposedSlots = state.proposedSlots.filter(s => s.id !== id);
            renderProposedSlots();
            renderCalendar();
        });

        list.appendChild(li);
    });
}

// -------------------------------------------------------------
// VIEW CONTROLLERS
// -------------------------------------------------------------
function showView(viewId) {
    // Hide all views
    document.querySelectorAll('.view-section').forEach(sec => {
        sec.classList.add('hidden');
    });

    // Show target view
    const view = document.getElementById(`view-${viewId}`);
    if (view) {
        view.classList.remove('hidden');
    }
    state.currentView = viewId;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// 1. CREATE VIEW INITIALIZATION
function initCreateView() {
    showView('create');
    state.proposedSlots = [];
    document.getElementById('poll-title').value = '';
    document.getElementById('poll-description').value = '';
    document.getElementById('organizer-name').value = '';
    document.getElementById('organizer-email').value = '';
    
    // Reset Char counters
    const titleCounter = document.getElementById('title-counter');
    const descCounter = document.getElementById('desc-counter');
    if (titleCounter) titleCounter.textContent = "0/100";
    if (descCounter) descCounter.textContent = "0/500";

    // Reset Type card
    const typeGroup = document.getElementById('type-card-group');
    const typeOneOne = document.getElementById('type-card-oneone');
    const pollTypeIn = document.getElementById('poll-type-input');
    if (typeGroup && typeOneOne && pollTypeIn) {
        typeGroup.classList.add('active');
        typeOneOne.classList.remove('active');
        pollTypeIn.value = 'group';
    }

    calMonth = new Date().getMonth();
    calYear = new Date().getFullYear();
    state.selectedDate = new Date();
    
    renderCalendar();
    updateSelectedDateLabel();
    renderProposedSlots();
}

async function handleCreatePollSubmit() {
    const title = document.getElementById('poll-title').value.trim();
    const description = document.getElementById('poll-description').value.trim();
    const duration = document.getElementById('poll-duration').value;
    const timezone = document.getElementById('poll-timezone').value;
    const name = document.getElementById('organizer-name').value.trim();
    const email = document.getElementById('organizer-email').value.trim();
    const pollType = document.getElementById('poll-type-input') ? document.getElementById('poll-type-input').value : 'group';

    if (!title || !name || !email) {
        showToast("Please fill in all required fields (*) in Section 1.", "error");
        return;
    }

    if (state.proposedSlots.length === 0) {
        showToast("Please propose at least one time slot in Section 2.", "error");
        return;
    }

    const payload = {
        poll_type: pollType,
        title: title,
        description: description,
        duration: duration,
        timezone: timezone,
        organizer_name: name,
        organizer_email: email,
        slots: state.proposedSlots
    };

    showLoading(true);
    try {
        const response = await fetch(`${API_BASE}/polls`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || "Failed to create poll.");
        }

        const poll = await response.json();
        showToast("Meeting poll created successfully!");
        
        // Redirect to results view for the newly created poll
        window.location.hash = `#/results/${poll.id}`;
    } catch (err) {
        showToast(err.message, "error");
    } finally {
        showLoading(false);
    }
}

// 2. VOTE VIEW INITIALIZATION
async function initVoteView(pollId) {
    showView('vote');
    state.voterChoices = {};
    
    // Clear inputs
    document.getElementById('voter-name').value = '';
    document.getElementById('voter-email').value = '';

    showLoading(true);
    try {
        const response = await fetch(`${API_BASE}/polls/${pollId}`);
        if (!response.ok) throw new Error("Poll not found.");
        
        const poll = await response.json();
        state.currentPoll = poll;
        
        // Update meeting header details
        document.getElementById('vote-org-name').textContent = poll.organizer_name;
        document.getElementById('vote-meeting-title').textContent = poll.title;
        document.getElementById('vote-meeting-desc').textContent = poll.description || 'No description provided.';
        document.getElementById('vote-meeting-duration').textContent = `${poll.duration} minutes`;
        document.getElementById('vote-meeting-timezone').textContent = poll.timezone;

        // Set badges/labels
        const modeBadge = document.getElementById('vote-meeting-mode-badge');
        if (modeBadge) {
            modeBadge.textContent = poll.poll_type === 'one_on_one' ? '1-on-1 Scheduler' : 'Group Poll';
        }
        
        const instText = document.getElementById('vote-instruction-text');
        if (instText) {
            instText.textContent = poll.poll_type === 'one_on_one' 
                ? 'This is a 1-on-1 booking scheduler. Please select exactly one slot to book your meeting.' 
                : 'Click on the response buttons to state your availability for each proposed time.';
        }

        // Build result page link
        document.getElementById('view-results-link').href = `#/results/${pollId}`;

        // Populate availability list
        renderVotingSlots();
    } catch (err) {
        showToast(err.message, "error");
        window.location.hash = '#/create';
    } finally {
        showLoading(false);
    }
}

function renderVotingSlots() {
    const container = document.getElementById('voting-slots-container');
    if (!container || !state.currentPoll) return;

    container.innerHTML = '';
    
    const displayTz = document.getElementById('vote-voter-timezone').value;
    const isFinalized = !!state.currentPoll.finalized_slot_id;
    const isOneOnOne = state.currentPoll.poll_type === 'one_on_one';

    state.currentPoll.slots.forEach(slot => {
        const formatted = formatSlotTimeRange(slot.start_time, slot.end_time, displayTz);
        const isBookedThis = state.currentPoll.finalized_slot_id === slot.id;
        
        const card = document.createElement('div');
        card.className = 'voting-slot-card';

        if (isOneOnOne) {
            const isSelected = state.voterChoices[slot.id] === 'yes';
            if (isSelected) card.classList.add('selected-radio');
            if (isFinalized && !isBookedThis) card.classList.add('booked');

            let actionHtml = '';
            if (isFinalized) {
                if (isBookedThis) {
                    actionHtml = `<span class="badge-organizer" style="background:var(--success-bg); border-color:var(--success-border); color:var(--success);">Booked</span>`;
                } else {
                    actionHtml = `<span class="badge-organizer" style="background:#f1f5f9; border-color:#cbd5e1; color:#94a3b8;">Unavailable</span>`;
                }
            } else {
                actionHtml = `
                    <button type="button" class="btn-select-slot ${isSelected ? 'selected' : ''}" data-slot-id="${slot.id}">
                        ${isSelected ? 'Selected' : 'Select & Book'}
                    </button>
                `;
            }

            card.innerHTML = `
                <div class="voting-slot-info">
                    <div class="vote-calendar-badge">
                        <span class="badge-month">${formatted.month}</span>
                        <span class="badge-day">${formatted.day}</span>
                    </div>
                    <div class="vote-slot-datetime">
                        <span class="vote-slot-dayname">${formatted.weekday}, ${formatted.dateString.split(',').slice(1).join(',')}</span>
                        <span class="vote-slot-time-range">${formatted.timeRange}</span>
                    </div>
                </div>
                <div class="vote-actions">
                    ${actionHtml}
                </div>
            `;

            const selectBtn = card.querySelector('.btn-select-slot');
            if (selectBtn) {
                selectBtn.addEventListener('click', () => {
                    // Reset all choices to 'no'
                    state.currentPoll.slots.forEach(s => {
                        state.voterChoices[s.id] = 'no';
                    });
                    // Set this one as 'yes'
                    state.voterChoices[slot.id] = 'yes';
                    renderVotingSlots();
                });
            }
        } else {
            // Standard Group Rating Choices (Yes, Maybe, No)
            if (!state.voterChoices[slot.id]) {
                state.voterChoices[slot.id] = 'no';
            }
            const currentChoice = state.voterChoices[slot.id];

            card.innerHTML = `
                <div class="voting-slot-info">
                    <div class="vote-calendar-badge">
                        <span class="badge-month">${formatted.month}</span>
                        <span class="badge-day">${formatted.day}</span>
                    </div>
                    <div class="vote-slot-datetime">
                        <span class="vote-slot-dayname">${formatted.weekday}, ${formatted.dateString.split(',').slice(1).join(',')}</span>
                        <span class="vote-slot-time-range">${formatted.timeRange}</span>
                    </div>
                </div>
                
                <div class="vote-choices-group">
                    <button type="button" class="vote-choice-btn choice-yes ${currentChoice === 'yes' ? 'active' : ''}" data-slot-id="${slot.id}" data-choice="yes" ${isFinalized ? 'disabled' : ''}>
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Yes
                    </button>
                    <button type="button" class="vote-choice-btn choice-if ${currentChoice === 'if_need_be' ? 'active' : ''}" data-slot-id="${slot.id}" data-choice="if_need_be" ${isFinalized ? 'disabled' : ''}>
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="16" x2="12" y2="12"></line>
                            <line x1="12" y1="8" x2="12.01" y2="8"></line>
                        </svg>
                        Maybe
                    </button>
                    <button type="button" class="vote-choice-btn choice-no ${currentChoice === 'no' ? 'active' : ''}" data-slot-id="${slot.id}" data-choice="no" ${isFinalized ? 'disabled' : ''}>
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                        No
                    </button>
                </div>
            `;

            // Choice button click handlers
            card.querySelectorAll('.vote-choice-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    if (isFinalized) return;
                    
                    const slotId = e.currentTarget.getAttribute('data-slot-id');
                    const choice = e.currentTarget.getAttribute('data-choice');

                    state.voterChoices[slotId] = choice;

                    card.querySelectorAll('.vote-choice-btn').forEach(b => b.classList.remove('active'));
                    e.currentTarget.classList.add('active');
                });
            });
        }

        container.appendChild(card);
    });

    if (isFinalized) {
        const notice = document.createElement('p');
        notice.style.color = 'var(--success)';
        notice.style.fontWeight = 'bold';
        notice.style.textAlign = 'center';
        notice.style.marginTop = '1.5rem';
        notice.textContent = isOneOnOne 
            ? "This slot has been booked and finalized. Responses are now locked."
            : "This meeting poll has been finalized. Selections are locked.";
        container.appendChild(notice);
    }
}

async function handleVoteSubmit() {
    if (!state.currentPoll) return;
    
    if (state.currentPoll.finalized_slot_id) {
        showToast("This poll has been finalized and cannot accept more votes.", "error");
        return;
    }

    const name = document.getElementById('voter-name').value.trim();
    const email = document.getElementById('voter-email').value.trim();

    if (!name || !email) {
        showToast("Please enter your name and email to submit availability.", "error");
        return;
    }

    // For 1-on-1, ensure exactly one slot is voted 'yes'
    const isOneOnOne = state.currentPoll.poll_type === 'one_on_one';
    if (isOneOnOne) {
        const hasSelection = Object.values(state.voterChoices).some(c => c === 'yes');
        if (!hasSelection) {
            showToast("Please select a slot to book.", "error");
            return;
        }
    }

    const payload = {
        voter_name: name,
        voter_email: email,
        choices: state.voterChoices
    };

    showLoading(true);
    try {
        const response = await fetch(`${API_BASE}/polls/${state.currentPoll.id}/vote`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || "Failed to submit votes.");
        }

        showToast(isOneOnOne ? "Meeting successfully booked!" : "Thank you! Your availability has been recorded.");
        
        // Redirect to results view
        window.location.hash = `#/results/${state.currentPoll.id}`;
    } catch (err) {
        showToast(err.message, "error");
    } finally {
        showLoading(false);
    }
}

// 3. RESULTS VIEW INITIALIZATION
async function initResultsView(pollId) {
    showView('results');
    
    showLoading(true);
    try {
        const response = await fetch(`${API_BASE}/polls/${pollId}`);
        if (!response.ok) throw new Error("Poll not found.");
        
        const poll = await response.json();
        state.currentPoll = poll;
        
        // Update details card
        document.getElementById('results-org-name').textContent = poll.organizer_name;
        document.getElementById('results-meeting-title').textContent = poll.title;
        document.getElementById('results-meeting-desc').textContent = poll.description || 'No description provided.';
        document.getElementById('results-meeting-duration').textContent = `${poll.duration} minutes`;
        document.getElementById('results-meeting-timezone').textContent = poll.timezone;

        // Set badges
        const modeBadge = document.getElementById('results-meeting-mode-badge');
        if (modeBadge) {
            modeBadge.textContent = poll.poll_type === 'one_on_one' ? '1-on-1 Scheduler' : 'Group Poll';
        }
        const titleLabel = document.getElementById('results-matrix-title');
        if (titleLabel) {
            titleLabel.textContent = poll.poll_type === 'one_on_one' ? 'Slot Booking Status' : 'Voter Response Heatmap';
        }

        // Share url
        const shareUrl = `${window.location.origin}/poll/${pollId}`;
        const shareInput = document.getElementById('share-url');
        shareInput.value = shareUrl;
        
        document.getElementById('back-to-vote-link').href = `#/vote/${pollId}`;

        // Populate finalize dropdown & matrix
        renderResultsMatrix();
        setupFinalizationControls();
        updateTemplateText();
    } catch (err) {
        showToast(err.message, "error");
        window.location.hash = '#/create';
    } finally {
        showLoading(false);
    }
}

function renderResultsMatrix() {
    const container = document.getElementById('results-matrix-container');
    if (!container || !state.currentPoll) return;

    container.innerHTML = '';
    
    const displayTz = document.getElementById('results-viewer-timezone').value;
    const slots = state.currentPoll.slots;
    const votes = state.currentPoll.votes;
    const finalizedId = state.currentPoll.finalized_slot_id;

    if (slots.length === 0) {
        container.innerHTML = `<p class="empty-list-msg">No proposed time slots found.</p>`;
        return;
    }

    // 1-on-1 Poll specific rendering
    if (state.currentPoll.poll_type === 'one_on_one') {
        const table = document.createElement('table');
        table.className = 'matrix-table';
        
        let html = `
            <thead>
                <tr>
                    <th style="text-align: left; padding-left: 1.5rem;">Time Slot</th>
                    <th>Status</th>
                    <th>Booked By</th>
                </tr>
            </thead>
            <tbody>
        `;
        
        // Find the voter who selected Yes for the finalized slot
        const bookingVoter = votes.length > 0 ? votes.find(v => {
            return v.choices[finalizedId] === 'yes';
        }) || votes[0] : null;

        slots.forEach(s => {
            const formatted = formatSlotTimeRange(s.start_time, s.end_time, displayTz);
            const isFinalizedSlot = s.id === finalizedId;
            
            let statusText = '';
            let statusClass = '';
            let voterDetails = '-';
            
            if (finalizedId) {
                if (isFinalizedSlot) {
                    statusText = 'Booked';
                    statusClass = 'choice-yes';
                    voterDetails = bookingVoter ? `${bookingVoter.voter_name} (${bookingVoter.voter_email})` : 'Booked';
                } else {
                    statusText = 'Unavailable';
                    statusClass = 'choice-pending';
                    voterDetails = '-';
                }
            } else {
                statusText = 'Available';
                statusClass = 'choice-if';
                voterDetails = 'Waiting for booking...';
            }
            
            html += `
                <tr>
                    <td style="text-align: left; padding-left: 1.5rem; font-weight: 700;">
                        <div style="display:flex; align-items:center; gap: 1.25rem;">
                            <div class="vote-calendar-badge" style="transform: scale(0.9); margin: -5px 0; flex-shrink:0;">
                                <span class="badge-month">${formatted.month}</span>
                                <span class="badge-day">${formatted.day}</span>
                            </div>
                            <div>
                                <div>${formatted.weekday}, ${formatted.dateString.split(',').slice(1).join(',')}</div>
                                <div style="font-size:0.9rem; color:var(--text-secondary); font-weight:500;">${formatted.timeRange}</div>
                            </div>
                        </div>
                    </td>
                    <td><span class="cell-choice ${statusClass}" style="padding: 0.35rem 1rem; border-radius: 50px;">${statusText}</span></td>
                    <td style="font-weight: 600; color: var(--text-secondary);">${voterDetails}</td>
                </tr>
            `;
        });
        
        html += `</tbody>`;
        table.innerHTML = html;
        container.appendChild(table);
        
        // Display finalized card if finalized
        const finalAlertCard = document.getElementById('finalized-alert-card');
        if (finalizedId) {
            const finalSlot = slots.find(s => s.id === finalizedId);
            if (finalSlot) {
                const formattedFinal = formatSlotTimeRange(finalSlot.start_time, finalSlot.end_time, displayTz);
                document.getElementById('finalized-time-badge').textContent = 
                    `${formattedFinal.dateString} @ ${formattedFinal.timeRange}`;
                document.getElementById('finalized-organizer-note').textContent = 
                    bookingVoter ? `This meeting has been booked by ${bookingVoter.voter_name} (${bookingVoter.voter_email}).` : '';
                finalAlertCard.classList.remove('hidden');
            }
        } else {
            finalAlertCard.classList.add('hidden');
        }
        return;
    }

    // Group Poll Tally computation
    const tallies = {}; // slot_id -> { yes: 0, if_need_be: 0, score: 0 }
    slots.forEach(s => {
        tallies[s.id] = { yes: 0, if_need_be: 0, score: 0 };
    });

    votes.forEach(v => {
        slots.forEach(s => {
            const choice = v.choices[s.id];
            if (choice === 'yes') {
                tallies[s.id].yes += 1;
                tallies[s.id].score += 2; // yes gets higher weight
            } else if (choice === 'if_need_be') {
                tallies[s.id].if_need_be += 1;
                tallies[s.id].score += 1; // if_need_be gets partial weight
            }
        });
    });

    // Find the slot with highest score (winner)
    let bestSlotId = null;
    let maxScore = -1;
    slots.forEach(s => {
        const score = tallies[s.id].score;
        if (score > maxScore && score > 0) {
            maxScore = score;
            bestSlotId = s.id;
        }
    });

    // Build Table Elements
    const table = document.createElement('table');
    table.className = 'matrix-table';

    // 1. Table Header (Slots details)
    let theadHtml = `
        <thead>
            <tr>
                <th class="col-voter">Participants (${votes.length})</th>
    `;
    slots.forEach(s => {
        const formatted = formatSlotTimeRange(s.start_time, s.end_time, displayTz);
        const isWinner = s.id === bestSlotId;
        theadHtml += `
            <th class="${isWinner ? 'slot-heatmap-winner' : ''}">
                <div class="matrix-slot-header">
                    ${isWinner ? `<span class="winner-highlight">Best Slot</span>` : ''}
                    <span class="matrix-slot-date">${formatted.weekday}, ${formatted.month} ${formatted.day}</span>
                    <span class="matrix-slot-time">${formatted.timeRange}</span>
                </div>
            </th>
        `;
    });
    theadHtml += `</tr></thead>`;
    table.innerHTML += theadHtml;

    // 2. Table Body (Voter rows)
    const tbody = document.createElement('tbody');
    if (votes.length === 0) {
        let rowHtml = `
            <tr>
                <td colspan="${slots.length + 1}" class="empty-list-msg">
                    No votes submitted yet. Share the link above to get responses!
                </td>
            </tr>
        `;
        tbody.innerHTML = rowHtml;
    } else {
        votes.forEach(v => {
            let rowHtml = `
                <tr>
                    <td class="cell-voter">
                        ${v.voter_name}
                        <span class="voter-email-sub">${v.voter_email}</span>
                    </td>
            `;
            slots.forEach(s => {
                const choice = v.choices[s.id] || 'pending';
                let displayVal = 'Pending';
                let cls = 'choice-pending';
                if (choice === 'yes') {
                    displayVal = '✓ Yes';
                    cls = 'choice-yes';
                } else if (choice === 'if_need_be') {
                    displayVal = 'Maybe';
                    cls = 'choice-if';
                } else if (choice === 'no') {
                    displayVal = '✗ No';
                    cls = 'choice-no';
                }

                rowHtml += `
                    <td class="cell-choice ${cls}">
                        ${displayVal}
                    </td>
                `;
            });
            rowHtml += `</tr>`;
            tbody.innerHTML += rowHtml;
        });
    }
    table.appendChild(tbody);

    // 3. Table Footer (Tallies row)
    const tfoot = document.createElement('tfoot');
    let tfootHtml = `
        <tr class="row-tally">
            <td style="text-align: left; font-weight: bold;">Total Agreement</td>
    `;
    slots.forEach(s => {
        const t = tallies[s.id];
        tfootHtml += `
            <td>
                <div class="tally-score">
                    <span class="tally-yes">${t.yes} Yes</span>
                    <span class="tally-if">${t.if_need_be} Maybe</span>
                </div>
            </td>
        `;
    });
    tfootHtml += `</tr>`;
    tfoot.innerHTML = tfootHtml;
    table.appendChild(tfoot);

    container.appendChild(table);

    // Display finalized card if finalized
    const finalAlertCard = document.getElementById('finalized-alert-card');
    if (finalizedId) {
        const finalSlot = slots.find(s => s.id === finalizedId);
        if (finalSlot) {
            const formattedFinal = formatSlotTimeRange(finalSlot.start_time, finalSlot.end_time, displayTz);
            document.getElementById('finalized-time-badge').textContent = 
                `${formattedFinal.dateString} @ ${formattedFinal.timeRange}`;
            document.getElementById('finalized-organizer-note').textContent = 
                `This meeting time was locked by ${state.currentPoll.organizer_name} (${state.currentPoll.organizer_email}).`;
            finalAlertCard.classList.remove('hidden');
        }
    } else {
        finalAlertCard.classList.add('hidden');
    }
}

function setupFinalizationControls() {
    const panel = document.getElementById('organizer-finalize-panel');
    const select = document.getElementById('finalize-slot-select');
    const btn = document.getElementById('finalize-submit-btn');
    const displayTz = document.getElementById('results-viewer-timezone').value;

    if (!panel || !select || !btn || !state.currentPoll) return;

    // Reset dropdown
    select.innerHTML = '<option value="">-- Choose a slot to finalize --</option>';
    btn.disabled = true;

    // If poll is already finalized, hide the control panel entirely
    if (state.currentPoll.finalized_slot_id) {
        panel.classList.add('hidden');
        return;
    }

    panel.classList.remove('hidden');

    state.currentPoll.slots.forEach(slot => {
        const formatted = formatSlotTimeRange(slot.start_time, slot.end_time, displayTz);
        const opt = document.createElement('option');
        opt.value = slot.id;
        opt.textContent = `${formatted.dateString} (${formatted.timeRange})`;
        select.appendChild(opt);
    });

    select.addEventListener('change', () => {
        btn.disabled = select.value === '';
    });
}

async function handleFinalizePoll() {
    if (!state.currentPoll) return;
    const slotId = document.getElementById('finalize-slot-select').value;

    if (!slotId) {
        showToast("Please select a slot to finalize.", "error");
        return;
    }

    showLoading(true);
    try {
        const response = await fetch(`${API_BASE}/polls/${state.currentPoll.id}/finalize`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ slot_id: slotId })
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || "Failed to finalize meeting.");
        }

        showToast("Meeting finalized! Responses are now locked.");
        
        // Reload details in results view
        initResultsView(state.currentPoll.id);
    } catch (err) {
        showToast(err.message, "error");
    } finally {
        showLoading(false);
    }
}

// -------------------------------------------------------------
// INVITATION TEMPLATE GENERATOR
// -------------------------------------------------------------
function updateTemplateText() {
    const textBox = document.getElementById('template-text-box');
    if (!textBox || !state.currentPoll) return;
    
    const title = state.currentPoll.title;
    const desc = state.currentPoll.description || 'No description provided.';
    const shareUrl = `${window.location.origin}/poll/${state.currentPoll.id}`;
    const displayTz = document.getElementById('results-viewer-timezone').value;
    
    // Format proposed slots
    const slotsText = state.currentPoll.slots.map((s, idx) => {
        const formatted = formatSlotTimeRange(s.start_time, s.end_time, displayTz);
        return `${idx + 1}. ${formatted.dateString} @ ${formatted.timeRange}`;
    }).join('\n');
    
    if (state.selectedTemplateTab === 'email') {
        textBox.textContent = `Subject: Vote on Meeting: ${title}\n\nHi everyone,\n\nI would like to invite you to the meeting "${title}". Please click the link below to select your availability slots so we can finalize the best meeting time:\n\n👉 Vote Link: ${shareUrl}\n\nProposed Times (${displayTz}):\n${slotsText}\n\nMeeting Description:\n${desc}\n\nBest regards,\n${state.currentPoll.organizer_name}`;
    } else {
        // Slack / Teams markdown
        textBox.textContent = `*Vote on Meeting: ${title}*\n\nHi team, please share your availability for *${title}* so we can lock in the best slot:\n\n👉 *Vote Link:* ${shareUrl}\n\n*Proposed Times (${displayTz}):*\n${slotsText.replace(/^\d+\./gm, '•')}\n\n_Description: ${desc}_`;
    }
}

// -------------------------------------------------------------
// ICS CALENDAR EXPORT LOGIC
// -------------------------------------------------------------
function downloadICSFile() {
    if (!state.currentPoll || !state.currentPoll.finalized_slot_id) return;
    
    const finalSlot = state.currentPoll.slots.find(s => s.id === state.currentPoll.finalized_slot_id);
    if (!finalSlot) return;

    const title = state.currentPoll.title;
    const description = state.currentPoll.description || 'Scheduled via MeetingPOLL';
    
    // Clean string helper for iCal format
    const cleanText = (t) => (t || '').replace(/\\/g, '\\\\').replace(/,/g, '\\,').replace(/;/g, '\\;').replace(/\n/g, '\\n');
    
    const formatDate = (isoString) => {
        const d = new Date(isoString);
        return d.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    };
    
    const start = formatDate(finalSlot.start_time);
    const end = formatDate(finalSlot.end_time);
    
    const lines = [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'PRODID:-//MeetingPOLL//MeetingPOLL Scheduler//EN',
        'CALSCALE:GREGORIAN',
        'METHOD:PUBLISH',
        'BEGIN:VEVENT',
        `UID:${state.currentPoll.id}@meetingpoll.com`,
        `DTSTAMP:${formatDate(new Date().toISOString())}`,
        `DTSTART:${start}`,
        `DTEND:${end}`,
        `SUMMARY:${cleanText(title)}`,
        `DESCRIPTION:${cleanText(description)}`,
        'STATUS:CONFIRMED',
        'SEQUENCE:0',
        'END:VEVENT',
        'END:VCALENDAR'
    ];
    
    const icsContent = lines.join('\r\n');
    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `${title.trim().replace(/[^a-zA-Z0-9]/g, '_')}_invite.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    showToast("Calendar invite (.ics) downloaded! Open it to add to Outlook/Google Calendar.");
}

// -------------------------------------------------------------
// HASH ROUTER
// -------------------------------------------------------------
function router() {
    const hash = window.location.hash || '#/create';
    
    // Support paths mapping (so `/poll/{id}` redirect is clean)
    const path = window.location.pathname;
    
    if (path.startsWith('/poll/')) {
        const parts = path.split('/');
        const pollId = parts[2];
        const isResults = parts[3] === 'results';
        
        // Clean pathname to avoid loop and force hash route redirect
        window.history.replaceState(null, '', '/');
        
        if (isResults) {
            window.location.hash = `#/results/${pollId}`;
            return;
        } else {
            window.location.hash = `#/vote/${pollId}`;
            return;
        }
    }

    if (hash === '#/create') {
        initCreateView();
    } else if (hash.startsWith('#/vote/')) {
        const pollId = hash.split('/')[2];
        initVoteView(pollId);
    } else if (hash.startsWith('#/results/')) {
        const pollId = hash.split('/')[2];
        initResultsView(pollId);
    } else {
        initCreateView();
    }
}

// -------------------------------------------------------------
// EVENT LISTENERS AND STARTUP
// -------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
    // Populate timezones list
    populateTimezoneDropdowns();

    // Input character counters
    const titleInput = document.getElementById('poll-title');
    const titleCounter = document.getElementById('title-counter');
    const descInput = document.getElementById('poll-description');
    const descCounter = document.getElementById('desc-counter');

    if (titleInput && titleCounter) {
        titleInput.addEventListener('input', () => {
            titleCounter.textContent = `${titleInput.value.length}/100`;
        });
    }
    if (descInput && descCounter) {
        descInput.addEventListener('input', () => {
            descCounter.textContent = `${descInput.value.length}/500`;
        });
    }

    // Poll Type selector cards click handling
    const groupCard = document.getElementById('type-card-group');
    const oneoneCard = document.getElementById('type-card-oneone');
    const pollTypeInput = document.getElementById('poll-type-input');

    if (groupCard && oneoneCard && pollTypeInput) {
        groupCard.addEventListener('click', () => {
            groupCard.classList.add('active');
            oneoneCard.classList.remove('active');
            pollTypeInput.value = 'group';
        });
        oneoneCard.addEventListener('click', () => {
            oneoneCard.classList.add('active');
            groupCard.classList.remove('active');
            pollTypeInput.value = 'one_on_one';
        });
    }

    // 1. Calendar Nav Listeners
    const prevBtn = document.getElementById('cal-prev-month');
    const nextBtn = document.getElementById('cal-next-month');
    
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            calMonth--;
            if (calMonth < 0) {
                calMonth = 11;
                calYear--;
            }
            renderCalendar();
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            calMonth++;
            if (calMonth > 11) {
                calMonth = 0;
                calYear++;
            }
            renderCalendar();
        });
    }

    // 2. Add Slot Listener
    const addSlotBtn = document.getElementById('add-slot-btn');
    if (addSlotBtn) {
        addSlotBtn.addEventListener('click', addProposedSlot);
    }

    // 3. Create Poll Submission
    const createPollBtn = document.getElementById('create-poll-btn');
    if (createPollBtn) {
        createPollBtn.addEventListener('click', handleCreatePollSubmit);
    }

    // 4. Timezone selector changes triggers redraws
    const pollTz = document.getElementById('poll-timezone');
    if (pollTz) {
        pollTz.addEventListener('change', () => {
            renderProposedSlots();
        });
    }

    const voteTz = document.getElementById('vote-voter-timezone');
    if (voteTz) {
        voteTz.addEventListener('change', () => {
            if (state.currentPoll) renderVotingSlots();
        });
    }

    const resultsTz = document.getElementById('results-viewer-timezone');
    if (resultsTz) {
        resultsTz.addEventListener('change', () => {
            if (state.currentPoll) {
                renderResultsMatrix();
                setupFinalizationControls();
                updateTemplateText();
            }
        });
    }

    // 5. Submit Vote Response
    const submitVoteBtn = document.getElementById('submit-vote-btn');
    if (submitVoteBtn) {
        submitVoteBtn.addEventListener('click', handleVoteSubmit);
    }

    // 6. Copy share URL to clipboard
    const copyBtn = document.getElementById('copy-share-url-btn');
    if (copyBtn) {
        copyBtn.addEventListener('click', () => {
            const shareInput = document.getElementById('share-url');
            if (shareInput) {
                shareInput.select();
                shareInput.setSelectionRange(0, 99999); // Mobile
                navigator.clipboard.writeText(shareInput.value)
                    .then(() => showToast("Share URL copied to clipboard!"))
                    .catch(() => showToast("Failed to copy link.", "error"));
            }
        });
    }

    // 7. Copy Invitation Template
    const copyTemplateBtn = document.getElementById('copy-template-btn');
    if (copyTemplateBtn) {
        copyTemplateBtn.addEventListener('click', () => {
            const text = document.getElementById('template-text-box').textContent;
            navigator.clipboard.writeText(text)
                .then(() => showToast("Invitation template copied!"))
                .catch(() => showToast("Failed to copy template.", "error"));
        });
    }

    // 8. Invitation Template Tabs switcher
    const emailTabBtn = document.getElementById('tab-btn-email');
    const slackTabBtn = document.getElementById('tab-btn-slack');
    
    if (emailTabBtn && slackTabBtn) {
        emailTabBtn.addEventListener('click', () => {
            emailTabBtn.classList.add('active');
            slackTabBtn.classList.remove('active');
            state.selectedTemplateTab = 'email';
            updateTemplateText();
        });
        slackTabBtn.addEventListener('click', () => {
            slackTabBtn.classList.add('active');
            emailTabBtn.classList.remove('active');
            state.selectedTemplateTab = 'slack';
            updateTemplateText();
        });
    }

    // 9. Download Calendar Invite (.ics)
    const downloadIcsBtn = document.getElementById('download-ics-btn');
    if (downloadIcsBtn) {
        downloadIcsBtn.addEventListener('click', downloadICSFile);
    }

    // 10. Finalize meeting submission
    const finalizeBtn = document.getElementById('finalize-submit-btn');
    if (finalizeBtn) {
        finalizeBtn.addEventListener('click', handleFinalizePoll);
    }

    // Initialize Router
    window.addEventListener('hashchange', router);
    
    // Initial Route check
    router();
});
